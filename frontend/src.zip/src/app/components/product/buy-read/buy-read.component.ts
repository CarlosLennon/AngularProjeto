import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-buy-read',
  templateUrl: './buy-read.component.html',
  styleUrls: ['./buy-read.component.css']
})
export class BuyReadComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
  }

}
