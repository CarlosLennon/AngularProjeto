export interface Product{
    id?: number
    name: string
    obs?: string
    price: number
   
}