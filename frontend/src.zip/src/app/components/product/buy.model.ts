export interface Buy
    {
      id?: number
      name: string
      price: number
      qtd?: number
      user?: string
      cpf?: number
      car?: number
    }